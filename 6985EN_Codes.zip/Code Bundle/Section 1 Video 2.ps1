﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 1, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# List the commands included in the Hyper-V PowerShell module
Get-Command –Module Hyper-V

# Display the short form of help for Get-VM
Get-Help Get-VM

# Display the examples for Get-VM
Get-Help Get-VM -Examples

# Stop all VMs that include the phrase "web" on hosts svhv1 and svhv2
Get-VM -Name "*web*" -ComputerName svhv1, svhv2 | Stop-VM

# open a remote PowerShell session on svhv2, list its VMs, and exit the session
Enter-PSSession svhv2
Get-VM
Exit-PSSession

# List commands in the FailoverCluster module
Get-Command -Module FailoverClusters