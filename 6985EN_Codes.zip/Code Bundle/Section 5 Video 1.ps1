﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 5, Video 1
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show all help for New-VM
Get-Help New-VM –Full

# Create a VM called "svFromPS"
New-VM -Name svFromPS -MemoryStartupBytes 1gb -BootDevice CD -SwitchName vSwitch -NewVHDPath 'C:\ClusterStorage\Volume1\Virtual Hard Disks\svFromPS-boot.vhdx' -NewVHDSizeBytes 60gb -Path 'C:\ClusterStorage\VMData1\Virtual Machines'

# Attach an ISO to the VM
Set-VMDvdDrive -VMName svFromPS -Path \\svstore\isos\WinServer2012R2.ISO

# Make the VM highly available
Add-ClusterVirtualMachineRole -VMName svFromPS

# Perform the above in a single line
New-VM -Name svFromPS2 -MemoryStartupBytes 1gb -BootDevice CD -SwitchName vSwitch -NewVHDPath 'C:\ClusterStorage\Volume1\Virtual Hard Disks\svFromPS2-boot.vhdx' -NewVHDSizeBytes 60gb -Path 'C:\ClusterStorage\VMData1\Virtual Machines' | Add-ClusterVirtualMachineRole

# Make the second VM not highly available
Remove-ClusterGroup -Name svFromPS2 -RemoveResources

# Remove the second VM
Remove-VM -Name svFromPS2

# Show the ID for VM 1
Get-VM svfromps | select VmID 

# Make VM1 not highly available using its ID
Get-VM svfromps | select VmID | Remove-ClusterGroup