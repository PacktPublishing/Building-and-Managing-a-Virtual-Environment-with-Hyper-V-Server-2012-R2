﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 1, Video 5
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Create a virtual switch on two hosts
New-VMSwitch -ComputerName svhv1, svhv2 -Name vSwitch -AllowManagementOS $false -NetAdapterName ConvergedTeam -MinimumBandwidthMode Weight -EnableIov $false

# Add virtual adapters for the management operating system to the new virtual switches
Add-VMNetworkAdapter -ComputerName svhv1, svhv2 -SwitchName vSwitch -Name Cluster
Add-VMNetworkAdapter -ComputerName svhv1, svhv2 -SwitchName vSwitch -Name LiveMigration

# Assign the new adapters to VLANs
Set-VMNetworkAdapterVan -Access -VlanId 10 -VMNetworkAdapter LiveMigration
Set-VMNetworkAdapterVan -Access -VlanId 15 -VMNetworkAdapter Cluster