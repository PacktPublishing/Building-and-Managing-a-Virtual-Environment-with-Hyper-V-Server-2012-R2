﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 8, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Take a checkpoint of svFromPS
Checkpoint-VM -VMName svFromPS -SnapshotName Pre-SP

# Remove checkpoints from all VMs
Remove-VM Snapshot –VMName *

# Show checkpoint cmdlets
Get-Command -Module Hyper-V -Name *checkpoint*, *snapshot*