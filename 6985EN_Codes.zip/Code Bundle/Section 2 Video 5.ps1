﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 2, Video 5
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Remove node svhv2
Remove-ClusterNode -Name svhv2 -Force

# Cleanup cluster data on svhv2
Clear-ClusterNode -Name svhv2

# Test existing cluster clhv1 with node candidate svhv2
Test-Cluster -Node clhv1, svhv2

# Show cluster quorum data
Get-ClusterQuorum | fl * 

# Add new cluster node svhv2
Add-ClusterNode -Name svhv2 -Cluster clhv1

# Show disks available to be added to the cluster
Get-ClusterAvailableDisk 

# Add disk 2 to the cluster
Get-ClusterAvailableDisk -Disk (Get-Disk -Number 2) | Add-ClusterDisk 