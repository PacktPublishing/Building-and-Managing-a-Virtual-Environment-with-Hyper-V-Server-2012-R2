﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 5, Video 5
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show integration services
Get-VMIntegrationService 

# Show VMs with Heartbeat and Shutdown services not in an OK status
Get-VMIntegrationService -VMName * -Name Heartbeat, Shutdown | where { $_.PrimaryStatusDescription -ne "OK" }

# Turn on heartbeat integration service
Enable-VMIntegrationService -Name Heartbeat -VMName * 

# Set delays
Set-VM -Name svFromPS -AutomaticStartDelay 10

# Set virtual memory priorities
Set-VMMemory -VMName svBasic, svFromPS -Priority 50

# View memory priority setting
Get-VMMemory -VMName svBasic, svFromPS | select Priority

# Show all cluster resources
Get-ClusterResource

# Show cluster resource for VM svFromPS
Get-ClusterResource –Name “Virtual Machine svFromPS”

# See cluster parameters on VM svFromPS
Get-ClusterResource –Name “virtual machine svfromps” | Get-ClusterParameter

# Change offline action to forced shutdown
Get-ClusterResource | where { $_.ResourceType -eq "Virtual Machine" } | Set-ClusterParameter -Name OfflineAction -Value 3 