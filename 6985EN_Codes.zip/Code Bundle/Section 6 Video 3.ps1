﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 6, Video 3
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Put svhv1 into maintenance mode
Suspend-ClusterNode -Name svhv1 -Drain -ForceDrain

# Take svhv2 out of maintenance mode
Resume-ClusterNode -Name svhv1 -Failback Immediate

# Set preferred owners
$VmID = (Get-VM "svbasic").VmID
Get-ClusterGroup -VmID $VmID | Set-ClusterOwnerNode -Owners svhv1

# Set possible owners
$VmID = (Get-VM "svbasic").VmID
Get-ClusterResource -VmID $VmID | Set-ClusterOwnerNode -Owners svhv1 

# Set affinity
(Get-ClusterGroup -Name "svsql*").AntiAffinityClassNames = "SQL Guests"

# Add another affinity group
(Get-ClusterGroup -Name "svsql*").AntiAffinityClassNames += "High Utilization Guests"

# Show affinity
(Get-ClusterGroup -Name "svsql*").AntiAffinityClassNames

# Clear affinity
(Get-ClusterGroup -Name "svsql*").AntiAffinityClassNames = “”