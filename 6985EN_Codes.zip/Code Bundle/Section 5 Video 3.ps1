﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 5, Video 3
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show details for New-VHD
Get-Help New-VHD -Full

# Create a new VHD in the default location
New-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx") –SizeBytes 60gb –Dynamic

# Show statistics on new VHDX
Get-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx")

# Show sample of conversion to fixed VHDX
Convert-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx") -DestinationPath ((Get-VMHost).VirtualMachinePath + "new-disk-fixed.vhdx") -VHDType Fixed -WhatIf

# Expand VHDX
Resize-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx") -SizeBytes 61gb

# Shrink VHDX (must be formatted)
Resize-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx") -SizeBytes 10gb

# Mount the VHDX to the local OS
Mount-VHD -Path ((Get-VMHost).VirtualMachinePath + "new-disk.vhdx")

# Show disks
Get-Disk

# Dismount VHDX mounted as disk 3
Dismount-VHD –DiskNumber 3

# Show disks attached to a VM
Get-VMHardDiskDrive -VMName svFromPS

# Add a VHDX to a VM
Add-VMHardDiskDrive -VMName svFromPS -ControllerType SCSI -ControllerNumber 0 -ControllerLocation 2

# Relocate a VHDX to another spot on the virtual SCSI controller
Get-VMHardDiskDrive -VMName svFromPS -ControllerLocation 2 -ControllerNumber 0 | Set-VMHardDiskDrive -ToControllerLocation 1