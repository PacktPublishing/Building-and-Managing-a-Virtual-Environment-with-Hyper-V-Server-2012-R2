﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 2, Video 1
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Assign IPs to the new adapters on the local node
New-NetIPAddress -IPAddress 192.168.10.10 -InterfaceAlias "vEthernet (LiveMigration)" -PrefixLength 24
New-NetIPAddress -IPAddress 192.168.15.10 -InterfaceAlias "vEthernet (Cluster)" -PrefixLength 24

# Assign IPs to the new adapters on the node named SVHV2 (use the same subnets!)
Enter-PSSession svhv2
New-NetIpAddress -IPAddress 192.168.10.11 -InterfaceAlias "vEthernet (LiveMigration)" -PrefixLength 24
New-NetIpAddress -IPAddress 192.168.15.11 -InterfaceAlias "vEthernet (Cluster)" -PrefixLength 24
Exit-PSSession

# check IP set results
gip

# Remove DNS registration from all virtual adapters
Set-DNSClient –InterfaceAlias “vEthernet*” –RegisterThisConnectionsAddress $false

# Remove DNS registration from all adapters that start with "PT"
Set-DNSClient –InterfaceAlias “PT*” –RegisterThisConnectionsAddress $false

# Check advanced properties on adapter named "PTL"
Get-NetAdapterAdvancedProperty PTL

# Set jumbo frames on all adapters that start with "PT"
Get-NetAdapterAdvancedProperty –InterfaceAlias PT* –DisplayName “Jumbo Frame” | Set-NetAdapterAdvancedProperty –DisplayValue "9KB MTU"

# Show jumbo frames on a virtual adapter in management OS named "LiveMigration"
Get-NetAdapterAdvancedProperty -InterfaceAlias "*LiveMigration*" 

# Set jumbo frames on all virtual adapters in management OS
Get-NetAdapterAdvancedProperty -InterfaceAlias "vEthernet*" | Set-NetAdapterAdvancedProperty –RegistryValue 9014

# Test jumbo frames
ping 192.168.50.100 -f -l 8000

# Show all advanced options on adapter PTL
Get-NetAdapterAdvancedSetting –InterfaceAlias PTL 

# Show advanced options on team adapter
Get-NetAdapterAdvancedProperty -InterfaceAlias (Get-NetLbfoTeam).Name 

# Disable VMQ on team adapter
Get-NetAdapterAdvancedProperty -InterfaceAlias (Get-NetLbfoTeam).Name -DisplayName "Virtual Machine Queues" | Set-NetAdapterAdvancedProperty -DisplayValue "Disabled"