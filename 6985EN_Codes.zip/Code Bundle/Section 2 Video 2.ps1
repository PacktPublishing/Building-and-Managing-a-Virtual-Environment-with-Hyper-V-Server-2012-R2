﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 2, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Set iSCSI Client to automatically start at windows boot
Set-Service -Name MSiSCSI -StartupType Automatic

# Start iSCSI Client service
Start-Service -Name MSiSCSI

# Connect to an iSCSI portal
New-IscsiTargetPortal -TargetPortalAddress 192.168.50.100 -InitiatorPortalAddress 192.168.50.11

# Connect to iSCSI target on portal that include the phrase "Quorum"
Get-IscsiTarget (Get-IscsiTarget).NodeAddress Get-IscsiTarget | where { $_.NodeAddress -like "*quorum*" } | Connect-IscsiTarget -IsMultipathEnabled $true -TargetPortalAddress 192.168.50.100 -InitiatorPortalAddress 192.168.50.11

# Open a second connection to the "Quorum" target using a different physical path
Get-IscsiTarget | where { $_.NodeAddress -like "*quorum*" } | Connect-IscsiTarget -IsMultipathEnabled $true -TargetPortalAddress 192.168.51.100 -InitiatorPortalAddress 192.168.51.11

# Set the existing connections to the "Quorum" target to automatically reconnect at reboot
Get-IscsiSession | where { $_.TargetNodeAddress -like "*quorum*" } | Register-IscsiSession

# Enable MPIO
Enable-WindowsFeature Multipath-IO 

# Set the global MPIO policy to least queue depth
Set-MSDSMGlobalDefaultLoadBalancePolicy -Policy LQD

# Enable MPIO on all iSCSI connections
Enable-MSDSMAutomaticClaim -BusType iSCSI

# List all disks
Get-Disk

# Set disk 1 to online
Set-Disk –Number 1 –IsOffline $false

# Initialize disk 1
Initialize-Disk –Number 1 –PartitionStyle GPT

# Create a new partition on disk 1 that uses all space
New-Partition –DiskNumber 1 –UseMaximumSize –DriveLetter Q

# Format the new partition
Format-Volume –DriveLetter Q –FileSystem NTFS –NewFileSystemLabel Quorum