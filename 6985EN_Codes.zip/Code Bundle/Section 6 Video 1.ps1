﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 6, Video 1
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Live Migrate svFromPS to any other node, method 1
Move-ClusterVirtualMachineRole -Name svFromPS

# Live Migrate svFromPS to svhv1, method 2
Move-VM -Name svFromPS -DestinationHost svhv1 