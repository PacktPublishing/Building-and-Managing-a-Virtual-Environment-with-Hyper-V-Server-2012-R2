﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 6, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Quick Migrate svFromPS, method 1
Move-ClusterVirtualMachineRole -Name svFromPS -Node svhv2 -MigrationType Quick

# Quick migrate svFromPS, method 2
Move-VM -Name svFromPS -ComputerName svhv1 -DestinationHost svhv2