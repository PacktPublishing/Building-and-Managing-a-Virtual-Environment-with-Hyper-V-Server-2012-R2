﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 8, Video 4
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Enable resource metering for all VMs
Enable-VMResourceMetering *

# Show basic metering statistics for all VMs
Measure-VM

# Show specific expanded statistic
Measure-VM * | select -ExpandProperty networkmeteredtrafficreport

# Set metering statistics back to zero
Reset-VMResourceMetering 

# Turn off resource metering
Disable-VMResourceMetering