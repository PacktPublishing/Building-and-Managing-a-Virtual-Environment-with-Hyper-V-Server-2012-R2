﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 8, Video 3
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Run Hyper-V BPA
Invoke-BpaModel -ComputerName svhv2 -ModelId Microsoft/Windows/Hyper-V -RepositoryPath c:\BPA 

# View BPA results
Get-BpaResult -ModelId Microsoft/Windows/Hyper-V -RepositoryPath C:\BPA

# Convert results to HTML
Get-BpaResult -ModelId Microsoft/Windows/Hyper-V -RepositoryPath C:\BPA | ConvertTo-Html | Out-File C:\BPA\report1.html 

# Convert results to CSV
Get-BpaResult -ModelId Microsoft/Windows/Hyper-V -RepositoryPath C:\BPA | ConvertTo-Csv | Out-File C:\BPA\report1.csv 