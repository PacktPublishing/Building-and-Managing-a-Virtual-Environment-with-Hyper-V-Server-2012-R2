﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 1, Video 4
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# List all network adapters in the local system
Get-NetAdapter

# Show IP information for the adapter named "Onboard"
gip -InterfaceAlias Onboard

# Show IP information for all adapters whose names start with "PT"
gip -InterfaceAlias PT*

# Create a network adapter team for converged fabric
New-NetLbfoTeam -Name ConvergedTeam -TeamingMode Lacp -LoadBalancingAlgorithm Dynamic

# Show status of network adapter team's members
Get-NetLbfoTeamMember

# Perform the above on a remote system named SVHV2
Enter-PSSession svhv2
New-NetLbfoTeam -Name ConvergedTeam -TeamMembers PBR, PBL -TeamingMode Lacp -LoadBalancingAlgorithm Dynamic
Get-NetLbfoTeamMember
Exit-PSSession