﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 3, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show all cluster disks
Get-ClusterResource | where { $_.OwnerGroup -eq "Available Storage" }

# Add all clusters disks to Cluster Shared Volumes
Get-ClusterResource | where { $_.OwnerGroup -eq "Available Storage" } | Add-ClusterSharedVolume

# Rename CSV "Cluster Disk 1" to "VMData1"
(Get-ClusterSharedVolume -Name "Cluster Disk 1").Name = "VMData1"

# Set CSV cache to 512MB
(Get-Cluster).BlockCacheSize = 512

# run a disk check on the CSV named VMData1
chkdsk c:\clusterstorage\vmdata1

# run a defrag pass on the CSV named VMData1
Suspend-ClusterResource -Name VMData1 -RedirectedAccess
defrag c:\ClusterStorage\VMData1
Resume-ClusterResource -Name VMData1