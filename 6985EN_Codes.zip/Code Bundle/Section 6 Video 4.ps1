﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 6, Video 4
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show all options on Move-VMStorage
Get-Help Move-VMStorage -Full

# Move svFromPS storage to same destination
Move-VMStorage –VMName svfromps –DestinationStoragePath \\svstore\vms

# Move different VHDX files for svFromPS to different destinations
$VHDs = @()
$VHDs += @{
    "SourceFilePath"      = "C:\ClusterStorage\Volume1\Virtual Hard Disks\svFromPS-boot.vhdx"
    "DestinationFilePath" = "\\svstore\SQL-VMs\Virtual Hard Disks\svFromPS-boot.vhdx"
    }
$VHDs += @{
    "SourceFilePath"      = "C:\ClusterStorage\Volume1\Virtual Hard Disks\svFromPS-data.vhdx"
    "DestinationFilePath" = "\\svstore\SQL-VMs\Virtual Hard Disks\svFromPS-data.vhdx"
    }

Move-VMStorage `
    -ComputerName svhv2 `
    -VMName svfromps `
    -VirtualMachinePath "\\svstore\SQL-VMs\Virtual Machines" `
    -SnapshotFilePath "\\svstore\SQL-VMs\Virtual Machines" `
    -SmartPagingFilePath "\\svstore\Virtual Machines" `
    -Vhds $VHDs