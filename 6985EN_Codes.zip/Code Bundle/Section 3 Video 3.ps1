﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 3, Video 3
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Open a connection to the "VMs" share on "SVSTORE" and then see the SMB dialect
ls \\svstore\VMs
Get-SmbConnection

# Create a new folder on the E: drive for sharing
md E:\Shares\Control -VMs 

# Share the folder and grant full access to the cluster, its nodes, and the domain admins
New-SmbShare -Name Control-VMs -Path E:\Shares\Control-VMS -FullAccess siron\svhv1$, siron\svhv2$, siron\clhv1$, “siron\Domain Admins”

# Set the NTFS permissions to match the share permissions
Set-SmbPathAcl –Name Control-VMs