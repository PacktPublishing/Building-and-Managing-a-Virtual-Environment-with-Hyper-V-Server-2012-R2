﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 7, Video 4
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show QoS settings on virtual switch
Get-VMSwitch | select Name, *bandwidth* 

# Set minimum weight QoS on a virtual adapter
Set-VMNetworkAdapter -ManagementOS -Name LiveMigration -MinimumBandwidthWeight 20

# Set maximum QoS on a virtual adapter
Set-VMNetworkAdapter -ManagementOS -Name LiveMigration -MaximumBandwidth 2gb 

# Enable SMB throttling
Add-WindowsFeature -Name FS-SMBBW

# Configure SMB throttling
Set-SmbBandwidthLimit -Category LiveMigration -BytesPerSecond 2gb 

# Disable SMB throttling, leave feature
Remove-SmbBandwidthLimit

# Set VHDX IOPS limit
Get-VMHardDiskDrive -VMName svbasic | Set-VMHardDiskDrive -MinimumIOPS 50 -MaximumIOPS 80

