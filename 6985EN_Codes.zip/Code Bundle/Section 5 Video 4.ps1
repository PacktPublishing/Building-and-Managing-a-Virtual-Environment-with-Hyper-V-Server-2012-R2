﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 5, Video 4
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show VM network adapters on VMs
Get-VMNetworkAdapter -VMName svhv1, svhv2

# Show VM network adapters in the management OS
Get-VMNetworkAdapter -ManagementOs 

# Show all info on Add-VMNetworkAdapter
Get-Help Add-VMNetworkAdapter -Full

# Show VLANs on adapters
Get-VMNetworkAdapterVlan -ManagementOS