﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 2, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Test computers svhv1 and svhv2 for failover cluster suitability
Test-Cluster svhv1, svhv2

# Show possible parameters for cluster validation
Test-Cluster -List

# Test only "Inventory" and "Validate System Drive Variable" options for computers svhv1 and svhv2
Test-Cluster -Node svhv1, svhv2 -Include "Inventory", "Validate System Drive Variable"

# Test only the system drive variable with a custom report name
Test-Cluster -Node svhv1, svhv2 -Include "Validate System Drive Variable" -ReportName SysDrive