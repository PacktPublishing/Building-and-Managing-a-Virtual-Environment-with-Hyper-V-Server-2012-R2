﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 5, Video 2
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Show virtual memory settings on all VMs
Get-VMMemory –VMName * 

# Show virtual memory settings on all VMs on computers svhv1 and svhv2
Get-VMMemory –ComputerName svhv1, svhv2 –VMName * | fl *

# Set virtual memory options on svFromPS
Set-VMMemory -VMName svFromPS -DynamicMemoryEnabled $true -MinimumBytes 512mb -MaximumBytes 2gb -Buffer 10 –Priority 20

# See options for MaximumAmountPerNumaNodeBytes
Get-Help -Name Set-VMMemory -Parameter MaximumAmountPerNumaNodeBytes

# Show NUMA status
Get-VMHostNumaNode

# Disable NUMA spanning
Set-VMHost -ComputerName svhv1 -NumaSpanningEnabled $false
Restart-Service vmms

# Adjust NUMA settings
Set-VMProcessor –VMName vmtest -MaximumCountPerNumaSocket 1 –MaximumCountPerNumaNode 1