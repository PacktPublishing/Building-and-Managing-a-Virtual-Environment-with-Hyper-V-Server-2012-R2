﻿<#
.SYNOPSIS
   Sample scripts.
.DESCRIPTION
   Sample script only; do not use in production.
.NOTES
	Companion script to "Highly Available Virtual Environments with Hyper-V Server 2012 R2", a video series from Packt Publishing.
	Section 6, Video 5
#>
Write-Warning "This script is not intended to be run. Please examine its contents."
return

# Perform a Shared Nothing Live Migration on a non-highly available VM
Move-VM -ComputerName svhv1 -Name svNonHA -DestinationHost svstore -DestinationStoragePath 'D:\Virtual Machines'